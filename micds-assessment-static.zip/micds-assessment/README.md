# MICDS Assessment (Spreadsheet-Style) — Static Version

This is a **static** (no Firebase) web app that looks/behaves like the spreadsheet:
- Tabs for Scores + Standards 1–4 + Approach to Learning
- 1–4 dropdown scoring with spreadsheet-like colors
- Reassessment textbox auto-locks unless score is **1–2**
- Export/Import JSON (teacher can export at end)
- Saves per-student (by email) in browser localStorage

## Run locally (Windows)
1) Install Node (LTS).
2) Open a terminal in this folder and run:
   - `npx serve`
3) Open the local URL it prints.

> If you double-click `index.html`, most browsers will block `type="module"` imports.
> Use a tiny local server (serve, Live Server extension, etc).

## Deploy (Netlify)
- Drag-and-drop the folder into Netlify **or**
- GitHub repo → Netlify → deploy
- Build command: *(none)*
- Publish directory: *(root of the folder)*

## Deploy (Replit)
- Create a "Static" or "HTML/CSS/JS" repl.
- Upload all files.
- Run with a static server (Replit usually auto-serves).

## Want cross-device storage?
Static works for demos, but if you need students/teachers on different devices to see the same data,
you’ll want a real database (e.g., Firebase Firestore). This static version intentionally avoids Firebase
so you stop getting the `No Firebase App [DEFAULT] has been created` error.
