
// Auto-generated data for MICDS Assessment (static, spreadsheet-style).

export const SCALE = [1,2,3,4];

export const ATL_SPORTS = [
  "Athletic Development",
  "Ultimate Frisbee",
  "Flag Football",
  "Tennis",
  "Squash",
  "Volleyball",
  "Floor Hockey",
  "Wrestling",
  "Yoga"
];

export const FUNDAMENTAL_MOVEMENTS = [
  {
    "name": "Lateral Squat (Athletic Development)"
  },
  {
    "name": "Lateral Lunge (Athletic Development)"
  },
  {
    "name": "Hip Hinge (RDL) (Athletic Development)"
  },
  {
    "name": "Horizontal Press (Push-Up) (Athletic Development)"
  },
  {
    "name": "A-Skip (Flag Football)"
  },
  {
    "name": "Elbow Proprio Plank (Volleyball)"
  },
  {
    "name": "In-Line Lunge (Volleyball)"
  },
  {
    "name": "Elbow Side Plank (Ultimate)"
  },
  {
    "name": "Lateral Leap (Ultimate)"
  },
  {
    "name": "Bear Crawl (Floor Hockey)"
  },
  {
    "name": "High Knees (Tennis)"
  },
  {
    "name": "Single Leg Hop and Stick (Tennis)"
  },
  {
    "name": "Back Plank (Squash)"
  },
  {
    "name": "Hip/Shoulder Separation (Squash)"
  }
];

export const SPECIFIC_SKILLS = [
  {
    "sport": "Ultimate Frisbee",
    "skills": [
      "Throwing",
      "Catching",
      "Defensive Skill"
    ]
  },
  {
    "sport": "Flag Football",
    "skills": [
      "Game Specific Agility",
      "Receiving Consistency",
      "Defensive Skills"
    ]
  },
  {
    "sport": "Squash",
    "skills": [
      "Court Positioning",
      "Forehand",
      "Backhand"
    ]
  },
  {
    "sport": "Tennis",
    "skills": [
      "Serving Consistency",
      "Forehand Consistency",
      "Backhand Consistency"
    ]
  },
  {
    "sport": "Volleyball",
    "skills": [
      "Bumping Accuracy",
      "Setting Accuracy",
      "Hitting Technique"
    ]
  },
  {
    "sport": "Floor Hockey",
    "skills": [
      "Passing/Receiving",
      "Movement Without Ball",
      "Defensive Skill"
    ]
  },
  {
    "sport": "Wrestling",
    "skills": [
      "Double Leg",
      "Half Nelson",
      "Switch"
    ]
  },
  {
    "sport": "Yoga",
    "skills": [
      "Plank\u2013Downward Dog\u2013Lunge Combo",
      "Warrior 2\u2013Reverse Triangle\u2013Extended Side Angle Combo",
      "Extended Side Angle\u2013Half Moon Combo"
    ]
  }
];

export const STANDARD2_QUESTIONS = [
  {
    "unit": "Athletic Development",
    "rubricId": "1",
    "question": "What are the benefits of using the force platform to track movement data?",
    "hasReassessment": true
  },
  {
    "unit": "Athletic Development",
    "rubricId": "2",
    "question": "Why are the exercises and activities we do in athletic development good for people that don't participate in athletics?",
    "hasReassessment": true
  },
  {
    "unit": "Ultimate",
    "rubricId": "3",
    "question": "Describe how you would teach someone how to throw a backhand.",
    "hasReassessment": true
  },
  {
    "unit": "Ultimate",
    "rubricId": "4",
    "question": "Many sports have a transfer of skills, strategies, tactics, and/or energy systems (similar intensities). List a sport (Level 3) or sports (Level 4) that have a transfer to the game of ultimate and explain what transfers.",
    "hasReassessment": true
  },
  {
    "unit": "Flag Football",
    "rubricId": "5",
    "question": "Explain three of the receiving routes taught during this unit.",
    "hasReassessment": true
  },
  {
    "unit": "Flag Football",
    "rubricId": "6",
    "question": "Flag football is a sport that requires high levels of speed. Explain why speed is important and how it impacts performance.",
    "hasReassessment": true
  },
  {
    "unit": "Tennis",
    "rubricId": "7",
    "question": "Explain why tennis players should aim to hit the ball in front of them when ground-stroking.",
    "hasReassessment": true
  },
  {
    "unit": "Tennis",
    "rubricId": "8",
    "question": "Explain why using a continental grip for serving is beneficial.",
    "hasReassessment": true
  },
  {
    "unit": "Squash",
    "rubricId": "9",
    "question": "Describe three ways to gain a point in squash.",
    "hasReassessment": true
  },
  {
    "unit": "Squash",
    "rubricId": "10",
    "question": "Explain why it is important to return to the \u201cT\u201d in squash after you hit the ball.",
    "hasReassessment": true
  },
  {
    "unit": "Volleyball",
    "rubricId": "11",
    "question": "Explain why communication is important for a successful volleyball team.",
    "hasReassessment": true
  },
  {
    "unit": "Volleyball",
    "rubricId": "12",
    "question": "Explain why being able to set the ball is important in volleyball.",
    "hasReassessment": true
  },
  {
    "unit": "Floor Hockey",
    "rubricId": "13",
    "question": "Explain why it is important to keep your stick on the floor when playing floor hockey.",
    "hasReassessment": true
  },
  {
    "unit": "Floor Hockey",
    "rubricId": "14",
    "question": "Explain why defensive positioning is important in floor hockey.",
    "hasReassessment": true
  },
  {
    "unit": "Yoga",
    "rubricId": "15",
    "question": "Explain how proper breathing techniques can improve your performance in yoga.",
    "hasReassessment": true
  }
];

export const STANDARD3_QUESTIONS = [
  {
    "unit": "Athletic Development",
    "rubricId": "16",
    "question": "What are the benefits of improving strength?",
    "hasReassessment": true
  },
  {
    "unit": "Athletic Development",
    "rubricId": "17",
    "question": "List the three energy systems and describe the intensities when each one becomes your body\u2019s main method for using energy.",
    "hasReassessment": true
  },
  {
    "unit": "Ultimate",
    "rubricId": "18",
    "question": "Ultimate is a very aerobic sport because it involves constant running. How can playing a fun, active game like ultimate help improve your ability to learn in the classroom? Explain your thinking.",
    "hasReassessment": true
  },
  {
    "unit": "Flag Football",
    "rubricId": "19",
    "question": "How does proper hydration impact your body when you are playing a sport?",
    "hasReassessment": true
  },
  {
    "unit": "Tennis",
    "rubricId": "20",
    "question": "Playing tennis provides a good amount of aerobic exercise. Aerobic exercise helps improve the function of your lungs. Describe how aerobic exercise improves your lungs.",
    "hasReassessment": true
  },
  {
    "unit": "Squash",
    "rubricId": "21",
    "question": "The stress on your bones from playing squash helps make your bones stronger. This only occurs when you have adequate vitamin D and calcium. Why does your body need vitamin D and calcium?",
    "hasReassessment": true
  },
  {
    "unit": "Volleyball",
    "rubricId": "22",
    "question": "Volleyball involves short bursts of fast movement during rallies, followed by brief rest periods. How can this type of movement help improve the health and function of your blood vessels? Explain your answer.",
    "hasReassessment": true
  },
  {
    "unit": "Floor Hockey",
    "rubricId": "23",
    "question": "Playing floor hockey is a good form of aerobic exercise, which helps improve your lungs work. How does regular exercise like this help your lungs become stronger and more efficient? Explain your answer.",
    "hasReassessment": true
  },
  {
    "unit": "Wrestling",
    "rubricId": "24",
    "question": "Wrestling is a physically intense sport that mainly uses the glycolytic (lactic acid) system. What can a wrestler do to improve their glycolytic (lactic acid) system?",
    "hasReassessment": true
  },
  {
    "unit": "Yoga",
    "rubricId": "25",
    "question": "Describe what is happening inside the body when the parasympathetic and sympathetic nervous systems are stimulated.",
    "hasReassessment": true
  }
];

export const STANDARD4_QUESTIONS = [
  {
    "unit": "Athletic Development",
    "rubricId": "26",
    "question": "When working in a group or team, how does hard work impact positive leadership and teamwork?",
    "hasReassessment": true
  },
  {
    "unit": "Ultimate",
    "rubricId": "27",
    "question": "Give characteristics of a successful group or team in full sentences below for each class. What are some possible behaviors or actions that show good leadership in a successful team?",
    "hasReassessment": true
  },
  {
    "unit": "Flag Football",
    "rubricId": "28",
    "question": "Why is showing respect an important part of being a positive leader and a good teammate?",
    "hasReassessment": true
  },
  {
    "unit": "Tennis",
    "rubricId": "29",
    "question": "Explain why it is important to encourage and support your teammates even when they make mistakes.",
    "hasReassessment": true
  },
  {
    "unit": "Squash",
    "rubricId": "30",
    "question": "Explain why it is important to listen to your teammates and consider their ideas during teamwork.",
    "hasReassessment": true
  },
  {
    "unit": "Volleyball",
    "rubricId": "31",
    "question": "Explain why taking responsibility for your role in a group helps the team succeed.",
    "hasReassessment": true
  },
  {
    "unit": "Floor Hockey",
    "rubricId": "32",
    "question": "Explain why communication and listening are important when working with others.",
    "hasReassessment": true
  },
  {
    "unit": "Yoga",
    "rubricId": "33",
    "question": "Explain how practicing mindfulness can help you work better with others and improve leadership.",
    "hasReassessment": true
  }
];

export const RUBRICS = {
  "1": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "2": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "3": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "4": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "5": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "6": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "7": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "8": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "9": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "10": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "11": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "12": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "13": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "14": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "15": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "16": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "17": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "18": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "19": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "20": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "21": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "22": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "23": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "24": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "25": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "26": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "27": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "28": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "29": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "30": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "31": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "32": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n",
  "33": "Level 4: Exceeding (thorough, accurate, detailed)\nLevel 3: Achieving (accurate, mostly complete)\nLevel 2: Developing (partial understanding / missing key ideas)\nLevel 1: Incomplete (little understanding / off-topic)\n"
};

// Scoring helper: color bucket like the spreadsheet.
export function scoreColor(score) {
  if (score === 4) return "s4";
  if (score === 3) return "s3";
  if (score === 2) return "s2";
  if (score === 1) return "s1";
  return "";
}
