
import { init } from "./app.js";
window.addEventListener("DOMContentLoaded", init);
