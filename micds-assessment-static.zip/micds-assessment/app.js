
import {
  ATL_SPORTS,
  FUNDAMENTAL_MOVEMENTS,
  SPECIFIC_SKILLS,
  STANDARD2_QUESTIONS,
  STANDARD3_QUESTIONS,
  STANDARD4_QUESTIONS,
  RUBRICS,
  scoreColor,
} from "./data.js";
import { getStudent, setStudent, listStudents, exportAll, importAll } from "./storage.js";

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const DEFAULT_EMAIL = "student@micds.org";

function blankStudent(email) {
  return {
    meta: { email, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    honorCode: false,

    // Standard 1
    s1: {
      fundamental: FUNDAMENTAL_MOVEMENTS.map(m => ({ name: m.name, studentScore: null, teacherScore: null })),
      specific: SPECIFIC_SKILLS.map(block => ({
        sport: block.sport,
        skills: block.skills.map(name => ({ name, studentScore: null, teacherScore: null }))
      })),
    },

    // Standard 2/3/4
    s2: STANDARD2_QUESTIONS.map(q => ({ ...q, score: null, answer: "", reassessment: "" })),
    s3: STANDARD3_QUESTIONS.map(q => ({ ...q, score: null, answer: "", reassessment: "" })),
    s4: {
      ratings: ATL_SPORTS.map(sport => ({
        sport,
        student: { responsible: null, respectful: null, effort: null },
        teacher: { responsible: null, respectful: null, effort: null },
      })),
      questions: STANDARD4_QUESTIONS.map(q => ({ ...q, score: null, answer: "", reassessment: "" })),
    },

    // ATL
    atl: {
      lateCount: 0,
      effortRows: ATL_SPORTS.map(sport => ({ sport, studentScore: null, teacherScore: null })),
    },
  };
}

let currentEmail = DEFAULT_EMAIL;
let state = null;

function ensureStudent(email) {
  const existing = getStudent(email);
  if (existing) return existing;
  const fresh = blankStudent(email);
  setStudent(email, fresh);
  return fresh;
}

function save() {
  state.meta.updatedAt = new Date().toISOString();
  setStudent(currentEmail, state);
  renderAll();
}

function setCellColor(el, score) {
  el.classList.remove("s1","s2","s3","s4");
  const c = scoreColor(score);
  if (c) el.classList.add(c);
}

function makeScoreSelect(value, onChange) {
  const sel = document.createElement("select");
  sel.className = "scoreSelect";
  const opt0 = document.createElement("option");
  opt0.value = "";
  opt0.textContent = "Select";
  sel.appendChild(opt0);
  [1,2,3,4].forEach(n => {
    const o = document.createElement("option");
    o.value = String(n);
    o.textContent = String(n);
    sel.appendChild(o);
  });
  sel.value = value == null ? "" : String(value);

  sel.addEventListener("change", () => {
    const v = sel.value === "" ? null : Number(sel.value);
    onChange(v);
  });
  setCellColor(sel, value);
  sel.addEventListener("change", () => setCellColor(sel, sel.value === "" ? null : Number(sel.value)));
  return sel;
}

function makeTextArea(value, onInput, placeholder="") {
  const ta = document.createElement("textarea");
  ta.className = "answer";
  ta.placeholder = placeholder;
  ta.value = value || "";
  ta.addEventListener("input", () => onInput(ta.value));
  return ta;
}

function calcStandardFromScores(scores) {
  const filled = scores.filter(s => typeof s === "number");
  if (!filled.length) return null;
  const avg = filled.reduce((a,b)=>a+b,0)/filled.length;
  return Math.round(avg*10)/10;
}

function drawPie(canvas, parts) {
  const ctx = canvas.getContext("2d");
  const total = parts.reduce((a,p)=>a+p.value,0) || 1;
  let start = -Math.PI/2;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  parts.forEach(p => {
    const ang = (p.value/total)*Math.PI*2;
    ctx.beginPath();
    ctx.moveTo(100,100);
    ctx.arc(100,100,90,start,start+ang);
    ctx.closePath();
    ctx.fillStyle = p.color;
    ctx.fill();
    start += ang;
  });
  // inner circle
  ctx.beginPath();
  ctx.arc(100,100,45,0,Math.PI*2);
  ctx.fillStyle = "#ffffff";
  ctx.fill();
}

function countLevels(scores) {
  const c = {1:0,2:0,3:0,4:0};
  scores.forEach(s => { if (c[s]!=null) c[s]++; });
  return c;
}

function renderHeader() {
  $("#student-email").value = currentEmail;
  $("#honor-code").checked = !!state.honorCode;

  const options = listStudents();
  const sel = $("#student-picker");
  sel.innerHTML = "";
  const empty = document.createElement("option");
  empty.value = "";
  empty.textContent = "Select saved student…";
  sel.appendChild(empty);
  options.forEach(e => {
    const o = document.createElement("option");
    o.value = e;
    o.textContent = e;
    sel.appendChild(o);
  });
}

function renderScoresAndGrades() {
  // Standard 1: use teacherScore if present else studentScore
  const s1scores = [];
  state.s1.fundamental.forEach(x => {
    const v = (x.teacherScore ?? x.studentScore);
    if (typeof v === "number") s1scores.push(v);
  });
  state.s1.specific.forEach(block => {
    block.skills.forEach(x => {
      const v = (x.teacherScore ?? x.studentScore);
      if (typeof v === "number") s1scores.push(v);
    });
  });
  const s1 = calcStandardFromScores(s1scores);

  const s2 = calcStandardFromScores(state.s2.map(q => q.score).filter(x=>typeof x==="number"));
  const s3 = calcStandardFromScores(state.s3.map(q => q.score).filter(x=>typeof x==="number"));
  const s4 = calcStandardFromScores(state.s4.questions.map(q=>q.score).filter(x=>typeof x==="number"));

  $("#s1-grade").textContent = s1 ?? "—";
  $("#s2-grade").textContent = s2 ?? "—";
  $("#s3-grade").textContent = s3 ?? "—";
  $("#s4-grade").textContent = s4 ?? "—";

  const finals = [s1,s2,s3,s4].filter(x=>typeof x==="number");
  const final = finals.length ? Math.round((finals.reduce((a,b)=>a+b,0)/finals.length)*10)/10 : null;
  $("#final-grade").textContent = final ?? "—";

  // Pie charts (counts)
  const makeChart = (id, scores) => {
    const c = countLevels(scores);
    const canvas = $(id);
    if (!canvas) return;
    drawPie(canvas, [
      { value: c[4], color: "#26ff2f" },
      { value: c[3], color: "#7db64d" },
      { value: c[2], color: "#ffd966" },
      { value: c[1], color: "#ff3b30" },
    ]);
    $(`${id}-legend`).textContent = `4:${c[4]}  3:${c[3]}  2:${c[2]}  1:${c[1]}`;
  };

  makeChart("#pie-s1", s1scores);
  makeChart("#pie-s2", state.s2.map(q=>q.score).filter(n=>typeof n==="number"));
  makeChart("#pie-s3", state.s3.map(q=>q.score).filter(n=>typeof n==="number"));
  makeChart("#pie-s4", state.s4.questions.map(q=>q.score).filter(n=>typeof n==="number"));
}

function renderStandard1() {
  const root = $("#s1-root");
  root.innerHTML = "";

  const card1 = document.createElement("div");
  card1.className = "sheetCard";
  card1.innerHTML = `<div class="sheetTitle">FUNDAMENTAL MOVEMENT ASSESSMENT</div>`;
  const table = document.createElement("table");
  table.className = "sheet";
  table.innerHTML = `
    <thead>
      <tr>
        <th>Movement</th>
        <th class="center">Student Score</th>
        <th class="center">Teacher Score</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tbody = table.querySelector("tbody");
  state.s1.fundamental.forEach((m, idx) => {
    const tr = document.createElement("tr");
    const tdName = document.createElement("td");
    tdName.textContent = m.name;
    tr.appendChild(tdName);

    const tdS = document.createElement("td");
    tdS.className="center";
    tdS.appendChild(makeScoreSelect(m.studentScore, (v)=>{ state.s1.fundamental[idx].studentScore=v; save(); }));
    tr.appendChild(tdS);

    const tdT = document.createElement("td");
    tdT.className="center";
    tdT.appendChild(makeScoreSelect(m.teacherScore, (v)=>{ state.s1.fundamental[idx].teacherScore=v; save(); }));
    tr.appendChild(tdT);

    tbody.appendChild(tr);
  });
  card1.appendChild(table);
  root.appendChild(card1);

  state.s1.specific.forEach((block, bi) => {
    const card = document.createElement("div");
    card.className = "sheetCard";
    card.innerHTML = `<div class="sheetTitle">SPECIFIC SKILL ASSESSMENT — ${block.sport.toUpperCase()}</div>`;
    const t = document.createElement("table");
    t.className="sheet";
    t.innerHTML = `
      <thead>
        <tr>
          <th>Skill</th>
          <th class="center">Student Score</th>
          <th class="center">Teacher Score</th>
        </tr>
      </thead>
      <tbody></tbody>
    `;
    const tb = t.querySelector("tbody");
    block.skills.forEach((sk, si) => {
      const tr = document.createElement("tr");
      const tdName = document.createElement("td"); tdName.textContent = sk.name; tr.appendChild(tdName);
      const tdS = document.createElement("td"); tdS.className="center";
      tdS.appendChild(makeScoreSelect(sk.studentScore, (v)=>{ state.s1.specific[bi].skills[si].studentScore=v; save(); }));
      tr.appendChild(tdS);
      const tdT = document.createElement("td"); tdT.className="center";
      tdT.appendChild(makeScoreSelect(sk.teacherScore, (v)=>{ state.s1.specific[bi].skills[si].teacherScore=v; save(); }));
      tr.appendChild(tdT);
      tb.appendChild(tr);
    });
    card.appendChild(t);
    root.appendChild(card);
  });
}

function renderQuestionTable(container, questions, onEdit) {
  container.innerHTML = "";

  const note = document.createElement("div");
  note.className="sheetNote";
  note.innerHTML = `
    <div class="honorBar">
      <div><b>MICDS HONOR CODE:</b> USE ONLY YOUR BRAIN TO ANSWER THESE QUESTIONS (NO AI, GOOGLE, CANVAS RESOURCES, ETC.)</div>
      <div>YOU MAY ONLY USE RESOURCES IF YOUR ANSWER IS RATED AS A 1 OR A 2</div>
    </div>
    <div class="smallMuted">Hover the [#] tag to view the rubric used to score that question.</div>
  `;
  container.appendChild(note);

  const t = document.createElement("table");
  t.className="sheet";
  t.innerHTML = `
    <thead>
      <tr>
        <th style="width:140px">Unit</th>
        <th>Concept</th>
        <th class="center" style="width:110px">Score</th>
        <th>Proof of Understanding</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tb = t.querySelector("tbody");

  questions.forEach((q, idx) => {
    const tr = document.createElement("tr");

    const tdU = document.createElement("td"); tdU.textContent = q.unit; tr.appendChild(tdU);

    const tdQ = document.createElement("td");
    const badge = document.createElement("span");
    badge.className="badge";
    badge.textContent = `[${q.rubricId || "?"}]`;
    badge.title = (q.rubricId && RUBRICS[q.rubricId]) ? RUBRICS[q.rubricId] : "Rubric not loaded.";
    tdQ.appendChild(badge);

    const qtext = document.createElement("span");
    qtext.textContent = " " + q.question;
    tdQ.appendChild(qtext);
    tr.appendChild(tdQ);

    const tdS = document.createElement("td"); tdS.className="center";
    tdS.appendChild(makeScoreSelect(q.score, (v)=>{ onEdit(idx, { score: v }); }));
    tr.appendChild(tdS);

    const tdA = document.createElement("td");
    tdA.appendChild(makeTextArea(q.answer, (v)=>onEdit(idx, { answer: v }), "Type your answer here…"));
    tr.appendChild(tdA);

    tb.appendChild(tr);

    // reassessment row
    const rtr = document.createElement("tr");
    rtr.className="reassessRow";
    const rtd = document.createElement("td");
    rtd.colSpan = 4;

    const locked = !(typeof q.score === "number" && q.score <= 2);
    rtd.innerHTML = `<div class="reassessLabel">PUT YOUR REASSESSMENT ANSWER HERE →</div>`;
    const rta = makeTextArea(q.reassessment, (v)=>onEdit(idx, { reassessment: v }),
      locked ? "Locked until score is 1–2." : "Reassessment answer…");
    rta.disabled = locked;
    if (locked) rta.classList.add("disabled");
    rtd.appendChild(rta);
    rtr.appendChild(rtd);
    tb.appendChild(rtr);
  });

  container.appendChild(t);
}

function renderStandard2() {
  renderQuestionTable($("#s2-root"), state.s2, (idx, patch) => {
    state.s2[idx] = { ...state.s2[idx], ...patch };
    save();
  });
}

function renderStandard3() {
  renderQuestionTable($("#s3-root"), state.s3, (idx, patch) => {
    state.s3[idx] = { ...state.s3[idx], ...patch };
    save();
  });
}

function renderStandard4() {
  // ratings
  const r = $("#s4-ratings");
  r.innerHTML = "";
  const card = document.createElement("div");
  card.className="sheetCard";
  card.innerHTML = `<div class="sheetTitle">RATINGS (SELF + TEACHER)</div>`;
  const t = document.createElement("table");
  t.className="sheet";
  t.innerHTML = `
    <thead>
      <tr>
        <th>Unit</th>
        <th class="center">Responsible & Prepared (Student)</th>
        <th class="center">Respectful & Works Well (Student)</th>
        <th class="center">Puts Forth Effort (Student)</th>
        <th class="center">Responsible & Prepared (Teacher)</th>
        <th class="center">Respectful & Works Well (Teacher)</th>
        <th class="center">Puts Forth Effort (Teacher)</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tb = t.querySelector("tbody");
  state.s4.ratings.forEach((row, idx) => {
    const tr = document.createElement("tr");
    const tdU = document.createElement("td"); tdU.textContent = row.sport; tr.appendChild(tdU);

    const mk = (side, key) => {
      const td = document.createElement("td"); td.className="center";
      td.appendChild(makeScoreSelect(row[side][key], (v)=>{ state.s4.ratings[idx][side][key]=v; save(); }));
      return td;
    };
    tr.appendChild(mk("student","responsible"));
    tr.appendChild(mk("student","respectful"));
    tr.appendChild(mk("student","effort"));
    tr.appendChild(mk("teacher","responsible"));
    tr.appendChild(mk("teacher","respectful"));
    tr.appendChild(mk("teacher","effort"));

    tb.appendChild(tr);
  });
  card.appendChild(t);
  r.appendChild(card);

  // questions
  renderQuestionTable($("#s4-questions"), state.s4.questions, (idx, patch) => {
    state.s4.questions[idx] = { ...state.s4.questions[idx], ...patch };
    save();
  });
}

function renderATL() {
  $("#atl-late-count").value = state.atl.lateCount;

  const score = (() => {
    const n = Number(state.atl.lateCount || 0);
    if (n === 0) return 4;
    if (n >= 1 && n <= 3) return 3;
    if (n >= 4 && n <= 6) return 2;
    return 1;
  })();
  $("#atl-score").textContent = String(score);

  const root = $("#atl-effort");
  root.innerHTML = "";
  const card = document.createElement("div");
  card.className="sheetCard";
  card.innerHTML = `<div class="sheetTitle">PUTS FORTH EFFORT TO LEARN</div>`;
  const t = document.createElement("table");
  t.className="sheet";
  t.innerHTML = `
    <thead>
      <tr>
        <th style="width:180px">Unit</th>
        <th class="center" style="width:140px">Student Score</th>
        <th class="center" style="width:140px">Teacher Score</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tb = t.querySelector("tbody");
  state.atl.effortRows.forEach((row, idx) => {
    const tr = document.createElement("tr");
    const tdU = document.createElement("td"); tdU.textContent = row.sport; tr.appendChild(tdU);

    const tdS = document.createElement("td"); tdS.className="center";
    tdS.appendChild(makeScoreSelect(row.studentScore, (v)=>{ state.atl.effortRows[idx].studentScore=v; save(); }));
    tr.appendChild(tdS);

    const tdT = document.createElement("td"); tdT.className="center";
    tdT.appendChild(makeScoreSelect(row.teacherScore, (v)=>{ state.atl.effortRows[idx].teacherScore=v; save(); }));
    tr.appendChild(tdT);

    tb.appendChild(tr);
  });
  card.appendChild(t);
  root.appendChild(card);
}

function renderAll() {
  renderHeader();
  renderScoresAndGrades();
  renderStandard1();
  renderStandard2();
  renderStandard3();
  renderStandard4();
  renderATL();
}

function setView(viewId) {
  $$(".tabbtn").forEach(b => b.classList.toggle("active", b.dataset.view === viewId));
  $$(".view").forEach(v => v.classList.toggle("hidden", v.id !== `view-${viewId}`));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function wireUI() {
  // tabs
  $$(".tabbtn").forEach(btn => btn.addEventListener("click", () => setView(btn.dataset.view)));

  // student switching
  $("#student-picker").addEventListener("change", () => {
    if (!$("#student-picker").value) return;
    currentEmail = $("#student-picker").value;
    state = ensureStudent(currentEmail);
    renderAll();
    setView("scores");
  });

  $("#load-student").addEventListener("click", () => {
    const email = ($("#student-email").value || "").trim();
    if (!email) return alert("Enter an email.");
    currentEmail = email;
    state = ensureStudent(currentEmail);
    renderAll();
    setView("scores");
  });

  $("#honor-code").addEventListener("change", () => { state.honorCode = $("#honor-code").checked; save(); });

  $("#atl-late-count").addEventListener("input", () => {
    state.atl.lateCount = Math.max(0, Number($("#atl-late-count").value || 0));
    save();
  });

  // export/import
  $("#export-btn").addEventListener("click", () => {
    const data = exportAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "micds-assessment-export.json";
    a.click();
    URL.revokeObjectURL(url);
  });

  $("#import-file").addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      importAll(JSON.parse(text));
      state = ensureStudent(currentEmail);
      renderAll();
      alert("Imported!");
    } catch (err) {
      alert("Import failed: " + err.message);
    } finally {
      e.target.value = "";
    }
  });

  $("#reset-student").addEventListener("click", () => {
    if (!confirm("Reset this student's data?")) return;
    state = blankStudent(currentEmail);
    save();
  });
}

export function init() {
  state = ensureStudent(currentEmail);
  wireUI();
  renderAll();
  setView("scores");
}
